<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('page-title', 'Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="fas fa-users me-2 text-primary"></i>Daftar Siswa Saya</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead style="background:#f8f9fa;">
                    <tr>
                        <th class="px-4 py-3" style="font-size:12px;color:#666;">No</th>
                        <th class="py-3" style="font-size:12px;color:#666;">Nama</th>
                        <th class="py-3" style="font-size:12px;color:#666;">Kelas</th>
                        <th class="py-3" style="font-size:12px;color:#666;">Tgl Lahir</th>
                        <th class="py-3" style="font-size:12px;color:#666;">Status</th>
                        <th class="py-3" style="font-size:12px;color:#666;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $siswaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4"><?php echo e($loop->iteration); ?></td>
                        <td>
                            <div class="fw-semibold"><?php echo e($siswa->nama); ?></div>
                            <small class="text-muted"><?php echo e($siswa->nomor_induk ?? '-'); ?></small>
                        </td>
                        <td><span class="badge bg-primary bg-opacity-10 text-primary"><?php echo e($siswa->kelas ?? '-'); ?></span></td>
                        <td><small><?php echo e($siswa->tanggal_lahir ? \Carbon\Carbon::parse($siswa->tanggal_lahir)->format('d/m/Y') : '-'); ?></small></td>
                        <td>
                            <span class="badge <?php echo e($siswa->status === 'aktif' ? 'bg-success' : 'bg-secondary'); ?>">
                                <?php echo e(ucfirst($siswa->status)); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('coach.siswa.show', $siswa)); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            <i class="fas fa-users fa-2x mb-2 d-block opacity-25"></i>
                            Belum ada siswa di kelas Anda
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($siswaList->hasPages()): ?>
        <div class="px-4 py-3"><?php echo e($siswaList->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.coach', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/youth-swimming-club/resources/views/coach/siswa/index.blade.php ENDPATH**/ ?>