<?php $__env->startSection('title', 'Riwayat Iuran'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <!-- Pembayaran Lunas -->
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-money-bill-wave me-2"></i>Riwayat Pembayaran Iuran
                    </h3>
                </div>
                <div class="card-body">
                    <?php if($pembayaranList->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Bulan/Tahun</th>
                                        <th>Jenis Pembayaran</th>
                                        <th>Jumlah</th>
                                        <th>Tanggal Bayar</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pembayaranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <strong>
                                                <?php echo e(\Carbon\Carbon::create($pembayaran->tahun, $pembayaran->bulan)->format('F Y')); ?>

                                            </strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-info">
                                                <?php echo e(ucwords(str_replace('_', ' ', $pembayaran->jenis_pembayaran))); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <strong class="text-success">
                                                Rp <?php echo e(number_format($pembayaran->jumlah, 0, ',', '.')); ?>

                                            </strong>
                                        </td>
                                        <td>
                                            <?php if($pembayaran->tanggal_bayar): ?>
                                                <?php echo e(\Carbon\Carbon::parse($pembayaran->tanggal_bayar)->format('d M Y')); ?>

                                                <br><small class="text-muted"><?php echo e($pembayaran->metode_pembayaran ?? 'Tunai'); ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">Belum dibayar</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('siswa.iuran.show', $pembayaran)); ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye me-1"></i>Detail
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($pembayaranList->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">Belum Ada Riwayat Pembayaran</h5>
                            <p class="text-muted">Riwayat pembayaran iuran Anda akan muncul di sini</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Angsuran/Cicilan -->
        <?php if($angsuranList->count() > 0): ?>
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-credit-card me-2"></i>Tagihan Angsuran
                    </h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Jenis Tagihan</th>
                                    <th>Total Tagihan</th>
                                    <th>Sudah Dibayar</th>
                                    <th>Sisa Tagihan</th>
                                    <th>Status</th>
                                    <th>Tanggal Tagihan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $angsuranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angsuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($angsuran->jenis_tagihan); ?></strong>
                                    </td>
                                    <td>
                                        <strong>Rp <?php echo e(number_format($angsuran->total_tagihan, 0, ',', '.')); ?></strong>
                                    </td>
                                    <td>
                                        <span class="text-success">
                                            Rp <?php echo e(number_format($angsuran->total_dibayar, 0, ',', '.')); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-warning">
                                            Rp <?php echo e(number_format($angsuran->sisa_tagihan, 0, ',', '.')); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if($angsuran->status === 'lunas'): ?>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check me-1"></i>Lunas
                                            </span>
                                        <?php elseif($angsuran->status === 'aktif'): ?>
                                            <span class="badge bg-warning">
                                                <i class="fas fa-clock me-1"></i>Belum Lunas
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><?php echo e(ucfirst($angsuran->status)); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($angsuran->tanggal_tagihan)->format('d M Y')); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/youth-swimming-club/resources/views/siswa/iuran/index.blade.php ENDPATH**/ ?>