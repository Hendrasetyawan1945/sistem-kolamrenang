<?php $__env->startSection('title', 'Detail Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>
                    <i class="fas fa-receipt me-2"></i>Detail Pembayaran
                </h2>
                <a href="<?php echo e(route('siswa.iuran.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Kembali
                </a>
            </div>

            <!-- Detail Pembayaran -->
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">
                        Pembayaran <?php echo e(ucwords(str_replace('_', ' ', $pembayaran->jenis_pembayaran))); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Periode:</strong></td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::create($pembayaran->tahun, $pembayaran->bulan)->format('F Y')); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Jenis Pembayaran:</strong></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <?php echo e(ucwords(str_replace('_', ' ', $pembayaran->jenis_pembayaran))); ?>

                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Total Jumlah:</strong></td>
                                    <td>
                                        <h5 class="text-success mb-0">
                                            Rp <?php echo e(number_format($pembayaran->jumlah, 0, ',', '.')); ?>

                                        </h5>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Status:</strong></td>
                                    <td>
                                        <?php if($pembayaran->status === 'lunas'): ?>
                                            <span class="badge bg-success fs-6">
                                                <i class="fas fa-check me-1"></i>Lunas
                                            </span>
                                        <?php elseif($pembayaran->status === 'belum_lunas'): ?>
                                            <span class="badge bg-warning fs-6">
                                                <i class="fas fa-clock me-1"></i>Belum Lunas
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary fs-6"><?php echo e($pembayaran->status); ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <?php if($pembayaran->tanggal_bayar): ?>
                                <tr>
                                    <td><strong>Tanggal Bayar:</strong></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($pembayaran->tanggal_bayar)->format('d F Y')); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($pembayaran->metode_pembayaran): ?>
                                <tr>
                                    <td><strong>Metode Pembayaran:</strong></td>
                                    <td><?php echo e($pembayaran->metode_pembayaran); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($pembayaran->sisa_bayar > 0): ?>
                                <tr>
                                    <td><strong>Sisa Bayar:</strong></td>
                                    <td>
                                        <span class="text-danger fw-bold">
                                            Rp <?php echo e(number_format($pembayaran->sisa_bayar, 0, ',', '.')); ?>

                                        </span>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php if($pembayaran->keterangan): ?>
                                <tr>
                                    <td><strong>Keterangan:</strong></td>
                                    <td><?php echo e($pembayaran->keterangan); ?></td>
                                </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Riwayat Angsuran (jika ada) -->
            <?php if($angsuranList->count() > 0): ?>
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-list me-2"></i>Riwayat Angsuran
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal Bayar</th>
                                    <th>Jumlah Bayar</th>
                                    <th>Metode</th>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $angsuranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $angsuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($angsuran->tanggal_bayar)->format('d M Y')); ?></td>
                                    <td>
                                        <strong class="text-success">
                                            Rp <?php echo e(number_format($angsuran->jumlah_bayar, 0, ',', '.')); ?>

                                        </strong>
                                    </td>
                                    <td><?php echo e($angsuran->metode_pembayaran ?? 'Tunai'); ?></td>
                                    <td><?php echo e($angsuran->keterangan ?? '-'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/youth-swimming-club/resources/views/siswa/iuran/show.blade.php ENDPATH**/ ?>