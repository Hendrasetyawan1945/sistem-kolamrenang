<?php $__env->startSection('title', 'Siswa Aktif'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .page-container {
        max-width: 1100px;
        margin: 0 auto;
        padding: 20px;
    }
    
    .page-header {
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 5px;
    }
    
    .page-subtitle {
        color: #6c757d;
        font-size: 0.9rem;
    }
    
    /* Stats bar */
    .stats-bar {
        background: white;
        border-radius: 8px;
        padding: 15px 20px;
        margin-bottom: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
    }
    
    .stats-info {
        display: flex;
        gap: 20px;
        align-items: center;
    }
    
    .stat-item {
        font-size: 0.8rem;
        color: #6c757d;
    }
    
    .stat-number {
        font-weight: 600;
        color: #2c3e50;
    }
    
    .action-buttons {
        display: flex;
        gap: 8px;
    }
    
    .btn-compact {
        padding: 6px 12px;
        font-size: 0.8rem;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.2s ease;
    }
    
    .btn-primary-compact {
        background: #007bff;
        color: white;
        border: 1px solid #007bff;
    }
    
    .btn-primary-compact:hover {
        background: #0056b3;
        border-color: #0056b3;
        color: white;
        text-decoration: none;
    }
    
    .btn-success-compact {
        background: #28a745;
        color: white;
        border: 1px solid #28a745;
    }
    
    .btn-success-compact:hover {
        background: #1e7e34;
        border-color: #1e7e34;
        color: white;
        text-decoration: none;
    }
    
    /* Simple Clean Table */
    .table-container {
        background: white;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        overflow: hidden;
    }
    
    .table-clean {
        width: 100%;
        margin: 0;
        border-collapse: collapse;
        font-size: 0.8rem;
        table-layout: fixed;
    }
    
    .table-clean thead {
        background: #f8f9fa;
    }
    
    .table-clean thead th {
        padding: 10px 12px;
        text-align: left;
        font-weight: 600;
        color: #495057;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        border-bottom: 1px solid #dee2e6;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .table-clean tbody tr {
        border-bottom: 1px solid #f1f3f4;
        transition: background-color 0.2s ease;
    }
    
    .table-clean tbody tr:hover {
        background-color: #f8f9fa;
    }
    
    .table-clean tbody td {
        padding: 12px;
        vertical-align: middle;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    /* Student Info Compact */
    .student-info {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .student-avatar {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: linear-gradient(135deg, #007bff, #0056b3);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 0.7rem;
        flex-shrink: 0;
    }
    
    .student-details .name {
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
        font-size: 0.8rem;
        line-height: 1.2;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .student-details .meta {
        color: #6c757d;
        font-size: 0.65rem;
        margin: 1px 0 0 0;
    }
    
    /* Email styling */
    .email-text {
        font-family: 'Segoe UI', system-ui, sans-serif;
        color: #495057;
        font-size: 0.75rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 180px;
        display: inline-block;
    }
    
    /* Simple badges */
    .badge-simple {
        padding: 2px 6px;
        border-radius: 10px;
        font-size: 0.65rem;
        font-weight: 500;
        display: inline-block;
    }
    
    .badge-kelas {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .badge-status-success {
        background: #d4edda;
        color: #155724;
    }
    
    .badge-status-warning {
        background: #fff3cd;
        color: #856404;
    }
    
    .badge-status-danger {
        background: #f8d7da;
        color: #721c24;
    }
    
    /* Action buttons compact */
    .action-group {
        display: flex;
        gap: 2px;
        align-items: center;
    }
    
    .btn-icon {
        width: 24px;
        height: 24px;
        border: 1px solid #dee2e6;
        background: white;
        border-radius: 3px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        text-decoration: none;
        transition: all 0.2s ease;
        font-size: 0.7rem;
        cursor: pointer;
    }
    
    .btn-icon:hover {
        background: #007bff;
        color: white;
        border-color: #007bff;
        text-decoration: none;
    }
    
    .btn-icon.btn-success:hover {
        background: #28a745;
        border-color: #28a745;
    }
    
    .btn-icon.btn-info:hover {
        background: #17a2b8;
        border-color: #17a2b8;
    }
    
    /* Inline Action Buttons */
    .btn-warning-inline:hover {
        background: #ffc107 !important;
        color: #212529 !important;
        border-color: #ffc107 !important;
    }
    
    .btn-danger-inline:hover {
        background: #dc3545 !important;
        color: white !important;
        border-color: #dc3545 !important;
    }
    
    .btn-delete-inline:hover {
        background: #dc3545 !important;
        color: white !important;
        border-color: #dc3545 !important;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .page-container {
            padding: 15px;
        }
        
        .table-clean {
            font-size: 0.75rem;
        }
        
        .table-clean thead th,
        .table-clean tbody td {
            padding: 10px 8px;
        }
        
        .student-info {
            flex-direction: column;
            align-items: flex-start;
            gap: 5px;
        }
        
        .stats-bar {
            flex-direction: column;
            align-items: stretch;
        }
        
        .stats-info {
            justify-content: space-around;
        }
        
        .action-buttons {
            justify-content: center;
        }
    }
</style>

<div class="page-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1 class="page-title">
            <i class="fas fa-users me-2"></i>Siswa Aktif
        </h1>
        <p class="page-subtitle">Kelola data siswa aktif dan akun login mereka</p>
    </div>

    <!-- Stats Bar -->
    <div class="stats-bar">
        <div class="stats-info">
            <div class="stat-item">
                Total: <span class="stat-number"><?php echo e($totalSiswa); ?></span>
            </div>
            <div class="stat-item">
                Punya Akun: <span class="stat-number"><?php echo e($sudahPunyaAkun); ?></span>
            </div>
            <div class="stat-item">
                Belum Akun: <span class="stat-number"><?php echo e($belumPunyaAkun); ?></span>
            </div>
            <div class="stat-item">
                Email Valid: <span class="stat-number"><?php echo e($emailValid); ?></span>
            </div>
        </div>
        <div class="action-buttons">
            <?php if($belumPunyaAkun > 0): ?>
                <button type="button" class="btn-compact btn-success-compact" onclick="openBulkAkunModal()">
                    <i class="fas fa-users me-1"></i>Buat Akun (<?php echo e($belumPunyaAkun); ?>)
                </button>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.akun.index')); ?>" class="btn-compact btn-primary-compact">
                <i class="fas fa-user-cog me-1"></i>Kelola Akun
            </a>
        </div>
    </div>

    <?php if($totalSiswa > 0): ?>
    <div style="background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 6px; padding: 12px; margin-bottom: 20px; font-size: 0.85rem;">
        <i class="fas fa-info-circle text-info me-2"></i>
        <strong>Info:</strong> Menampilkan <?php echo e($totalSiswa); ?> siswa aktif. 
        Jika ada siswa yang tidak muncul di daftar ini tapi ada di catatan waktu, 
        kemungkinan status mereka adalah "cuti" atau "nonaktif". 
        Periksa menu <a href="<?php echo e(route('admin.siswa-cuti')); ?>" class="text-decoration-none">Siswa Cuti</a> 
        atau <a href="<?php echo e(route('admin.siswa-nonaktif')); ?>" class="text-decoration-none">Siswa Nonaktif</a>.
    </div>
    <?php endif; ?>

    <!-- Simple Table -->
    <div class="table-container">
        <?php if($siswas->count() > 0): ?>
            <table class="table-clean">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th width="200">Siswa</th>
                        <th width="180">Email</th>
                        <th width="60">Kelas</th>
                        <th width="90">Status Akun</th>
                        <th width="120">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($index + 1); ?></td>
                        <td>
                            <div class="student-info">
                                <div class="student-avatar">
                                    <?php echo e(strtoupper(substr($siswa->nama, 0, 2))); ?>

                                </div>
                                <div class="student-details">
                                    <div class="name"><?php echo e($siswa->nama); ?></div>
                                    <div class="meta"><?php echo e($siswa->jenis_kelamin == 'L' ? 'L' : 'P'); ?> • <?php echo e($siswa->tanggal_lahir->age); ?>th</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php if($siswa->email): ?>
                                <span class="email-text"><?php echo e($siswa->email); ?></span>
                                <?php if(!filter_var($siswa->email, FILTER_VALIDATE_EMAIL)): ?>
                                    <span style="color: #dc3545; margin-left: 5px;">✗</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($siswa->kelas): ?>
                                <span class="badge-simple badge-kelas">
                                    <?php if(is_object($siswa->kelas) && isset($siswa->kelas->nama_kelas)): ?>
                                        <?php echo e($siswa->kelas->nama_kelas); ?>

                                    <?php else: ?>
                                        <?php echo e(is_string($siswa->kelas) ? $siswa->kelas : 'N/A'); ?>

                                    <?php endif; ?>
                                </span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($siswa->user): ?>
                                <span class="badge-simple badge-status-success">✓ Ada Akun</span>
                            <?php else: ?>
                                <?php if($siswa->email && filter_var($siswa->email, FILTER_VALIDATE_EMAIL)): ?>
                                    <span class="badge-simple badge-status-warning">⏳ Siap Dibuat</span>
                                <?php else: ?>
                                    <span class="badge-simple badge-status-danger">✗ Email Invalid</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-group">
                                <!-- Edit -->
                                <a href="<?php echo e(route('admin.siswa.edit', $siswa)); ?>" class="btn-icon" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                
                                <!-- Account -->
                                <?php if($siswa->user): ?>
                                    <a href="<?php echo e(route('admin.akun.show', $siswa->user)); ?>" class="btn-icon btn-info" title="Akun">
                                        <i class="fas fa-user"></i>
                                    </a>
                                <?php else: ?>
                                    <?php if($siswa->email && filter_var($siswa->email, FILTER_VALIDATE_EMAIL)): ?>
                                        <form method="POST" action="<?php echo e(route('admin.siswa.generate-akun', $siswa)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn-icon btn-success" title="Buat Akun"
                                                    onclick="return confirm('Buat akun untuk <?php echo e($siswa->nama); ?>?')">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <!-- More Actions - Inline Horizontal -->
                                <form method="POST" action="<?php echo e(route('admin.siswa.update-status', $siswa)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="cuti">
                                    <button type="submit" class="btn-icon btn-warning-inline" 
                                            onclick="return confirm('Ubah status <?php echo e($siswa->nama); ?> menjadi CUTI?')"
                                            title="Cuti">
                                        <i class="fas fa-pause"></i>
                                    </button>
                                </form>
                                
                                <form method="POST" action="<?php echo e(route('admin.siswa.update-status', $siswa)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="nonaktif">
                                    <button type="submit" class="btn-icon btn-danger-inline" 
                                            onclick="return confirm('Ubah status <?php echo e($siswa->nama); ?> menjadi NONAKTIF?')"
                                            title="Nonaktif">
                                        <i class="fas fa-stop"></i>
                                    </button>
                                </form>
                                
                                <form method="POST" action="<?php echo e(route('admin.siswa.destroy', $siswa)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-icon btn-delete-inline" 
                                            onclick="return confirm('HAPUS data <?php echo e($siswa->nama); ?>?')"
                                            title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div style="text-align: center; padding: 3rem; color: #6c757d;">
                <i class="fas fa-users" style="font-size: 3rem; opacity: 0.3; margin-bottom: 1rem;"></i>
                <h5>Belum Ada Siswa Aktif</h5>
                <p>Belum ada siswa dengan status aktif.</p>
                <a href="<?php echo e(route('admin.calon-siswa')); ?>" class="btn-compact btn-primary-compact">
                    <i class="fas fa-user-plus me-1"></i>Lihat Calon Siswa
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show mt-4" role="alert" style="border-radius: 8px; border: none;">
        <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show mt-4" role="alert" style="border-radius: 8px; border: none;">
        <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Modal Buat Akun Massal -->
<div class="modal fade" id="bulkAkunModal" tabindex="-1" aria-labelledby="bulkAkunModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="border-radius: 8px; border: none;">
            <div class="modal-header" style="background: linear-gradient(135deg, #28a745, #20c997); color: white; border-radius: 8px 8px 0 0;">
                <h5 class="modal-title" id="bulkAkunModalLabel">
                    <i class="fas fa-users me-2"></i>Buat Akun Massal untuk Siswa
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="<?php echo e(route('admin.siswa.buat-akun-otomatis')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body" style="padding: 1.5rem;">
                    <!-- Info -->
                    <div class="alert alert-info" style="border-radius: 6px; border: none; background: #e3f2fd;">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Pilih siswa yang akan dibuatkan akun login.</strong> 
                        Hanya siswa dengan email valid yang bisa dibuatkan akun.
                    </div>

                    <!-- Password Type -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">Jenis Password</label>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="password_type" value="default" id="passwordDefault" checked>
                                    <label class="form-check-label" for="passwordDefault">
                                        <strong>Default (123456)</strong><br>
                                        <small class="text-muted">Password standar untuk semua siswa</small>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="password_type" value="tanggal_lahir" id="passwordTglLahir">
                                    <label class="form-check-label" for="passwordTglLahir">
                                        <strong>Tanggal Lahir (ddmmyyyy)</strong><br>
                                        <small class="text-muted">Contoh: 15081995</small>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Daftar Siswa -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">Pilih Siswa</label>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small class="text-muted"><?php echo e($belumPunyaAkun); ?> siswa belum punya akun</small>
                            <div>
                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="selectAllSiswa()">Pilih Semua</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="deselectAllSiswa()">Batal Semua</button>
                            </div>
                        </div>
                        
                        <div style="max-height: 300px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 6px; padding: 0.5rem;">
                            <?php
                                $siswaEligible = $siswas->where('user', null)->filter(function($s) { 
                                    return $s->email && filter_var($s->email, FILTER_VALIDATE_EMAIL); 
                                });
                            ?>
                            
                            <?php $__currentLoopData = $siswaEligible; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check mb-2 p-2" style="border-bottom: 1px solid #f1f3f4;">
                                    <input class="form-check-input siswa-checkbox" type="checkbox" name="siswa_ids[]" value="<?php echo e($siswa->id); ?>" id="siswa<?php echo e($siswa->id); ?>">
                                    <label class="form-check-label w-100" for="siswa<?php echo e($siswa->id); ?>">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?php echo e($siswa->nama); ?></strong>
                                                <br><small class="text-muted"><?php echo e($siswa->email); ?> • <?php echo e(is_object($siswa->kelas) ? $siswa->kelas->nama_kelas ?? $siswa->kelas : $siswa->kelas); ?></small>
                                            </div>
                                            <span class="badge bg-success">Email Valid</span>
                                        </div>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($siswaEligible->isEmpty()): ?>
                                <div class="text-center text-muted py-3">
                                    <i class="fas fa-exclamation-triangle"></i>
                                    Tidak ada siswa dengan email valid yang belum punya akun
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Warning -->
                    <div class="alert alert-warning" style="border-radius: 6px; border: none; background: #fff3cd;">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Perhatian:</strong> Akun yang dibuat akan langsung bisa digunakan untuk login. 
                        Password bisa diubah nanti melalui menu Kelola Akun.
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid #dee2e6; padding: 1rem 1.5rem;">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check me-1"></i>Buat Akun Sekarang
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openBulkAkunModal() {
    const modal = new bootstrap.Modal(document.getElementById('bulkAkunModal'));
    modal.show();
}

function selectAllSiswa() {
    document.querySelectorAll('.siswa-checkbox').forEach(checkbox => {
        checkbox.checked = true;
    });
}

function deselectAllSiswa() {
    document.querySelectorAll('.siswa-checkbox').forEach(checkbox => {
        checkbox.checked = false;
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/youth-swimming-club/resources/views/admin/siswa/siswa-aktif.blade.php ENDPATH**/ ?>